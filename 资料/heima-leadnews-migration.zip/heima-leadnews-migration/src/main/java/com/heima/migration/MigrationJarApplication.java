package com.heima.migration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MigrationJarApplication {

    public static void main(String[] args) {
        SpringApplication.run(MigrationJarApplication.class,args);
    }
}
